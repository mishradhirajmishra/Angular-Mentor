import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormArray } from '@angular/forms';
import { ManteeService } from '../mantee.service';
import { JwtHelperService } from '@auth0/angular-jwt';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-profile-detail',
  templateUrl: './profile-detail.component.html',
  styleUrls: ['./profile-detail.component.css']
})
export class ProfileDetailComponent implements OnInit {
  helper = new JwtHelperService();
  user_key: String;
  proid: string;
  notsubmited = true;
  model: any;
  token: string;
  profileData: any;
  manteeProfileExplist: any;
  manteeProfileEdulist: any;
  formhide = true;
  profileImage: any;
  allProjects: any;
  allintrest: any;
  allPost: any;
  start: number=0;
  allPostTemp: any;
  contactExistVar: boolean;
  error: {};
  postLenth:number;
   postCount:number;
   postCountInc:number=0;
  constructor(public router: Router, private fb: FormBuilder, private ms: ManteeService, private actroute: ActivatedRoute, private ds: DomSanitizer) { }

  ngOnInit() {
    this.token = localStorage.getItem('token');
    this.token = this.helper.decodeToken(this.token);
    this.user_key = this.token['unique_key'];
    this.actroute.paramMap.subscribe(params => {
      this.proid = params.get('id');
    })
    this.ms.otherProfile({ 'user_key': this.proid }).subscribe(
      data => { this.profileData = data; },
      error => this.error = error
    );

    this.ms.profileImage({ 'user_key': this.proid }).subscribe(
      data => { this.profileImage = data; },
      error => this.error = error
    );
    this.ms.allApprovedProjectOfMantee({ 'user_key': this.proid }).subscribe(
      data => { this.allProjects = data; },
      error => this.error = error
    );
    this.ms.allIntrest({ 'user_key': this.proid }).subscribe(
      data => this.allintrest = data,
      error => this.error = error
    );
    this.getPostFirst();
    this.contactExist();
    this.loginstatus();
    this.allfollow();
    this.isfollow();
  }
  chk() {
    this.postCountInc = this.postCountInc + 2;
    // this.getPostRem();
  }
  loginStatusVar:string;
  loginstatus(){
    return  this.ms.loginStatusIndividual({ 'user_key': this.proid }).subscribe(
      data => { this.loginStatusVar =data},
      error => this.error = error
    );
  }

  getPostFirst() {
    return this.ms.manteeAllPost({ 'user_key': this.proid, 'start': this.start }).subscribe(
      data => { this.allPost = data.data; this.start = data.last_id;
         this.postCount=data.postCount; 
         if(this.postCount){
         this.postLenth=this.allPost.length; 
         }
        //  this.allPost =this.allPost.reverse();
         },
      error => this.error = error
    );
  }
  getPostRem() {
    return this.ms.manteeAllPost({ 'user_key': this.proid, 'start': this.start }).subscribe(
      data => {
      this.allPostTemp = data.data; this.start = data.last_id;
        this.allPost = [...this.allPost, ...this.allPostTemp];
        this.postCount=data.postCount; this.postLenth=this.allPost.length ;

      },
      error => this.error = error
    );
  }
  geturl(video: any) {
    return this.ds.bypassSecurityTrustResourceUrl('https://www.youtube.com/embed/' + video);
  }

   followMsg:string;
   followtxt:string="Follow";
  follow() {
    if(this.followtxt=="Follow"){
    return this.ms.addFollow({ 'admin_key': this.proid, 'user_key': this.user_key }).subscribe(
      data =>{ this.followMsg = data;this.followtxt="Following"},
      error => this.error = error
    );
    }
   }
   allfollowMsg:number;
   allfollow() {
    return this.ms.allFollowCount({ 'admin_key': this.proid}).subscribe(
      data => this.allfollowMsg = data,
      error => this.error = error
    );
   }
   isFllowMsg:string;
   isfollow() {
    return this.ms.isFollow({ 'admin_key': this.proid, 'user_key': this.user_key }).subscribe(
      data => this.isFllowMsg = data,
      error => this.error = error
    );
   }
  contactExist() {
    return this.ms.chatContactExist({ 'admin_key': this.user_key, 'user_key': this.proid }).subscribe(
      data => this.contactExistVar = data,
      error => this.error = error
    );
  }
  message() {

    if (!this.contactExistVar) {
    return this.ms.addChatContact({ 'admin_key': this.user_key, 'user_key': this.proid }).subscribe(
      data =>{console.log(data);this.contactExist(); this.router.navigate(['mentee/conversation/contact-list/' + this.proid]);},
      error => this.error = error
    );
    }
    else{
      this.router.navigate(['mentee/conversation/contact-list/' + this.proid]);
    }
  }
  meeetingRequest() {
    this.router.navigate(['mentee/req-meeting/' + this.proid]);
  }
}


